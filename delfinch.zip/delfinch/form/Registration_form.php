<?php
  include ("../mailer/mail.php");
  $con = mysqli_connect("localhost","root","toor","customer_db");

  if(isset($_POST['submit']))
  {
  $service = $_POST['service'];
  $city = $_POST['city'];
  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];
  $address = $_POST['address'];

  $query=mysqli_query($con,"INSERT INTO `customer_db`.`Reg_Complaint`(`Id`,`Service`,`City`,`Name`,`Phone`,`Email`,`Address`)VALUES(NULL,'$service','$city','$name','$phone','$email','$address')");
  if($query)
  {

   sendmail($city,$service,$name,$email,$phone,$address);
   header('Location: thank_you.html');

}else {

  echo "<script>alert('locho')</script>";


}}
 ?>



﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
    <!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
    <!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
    <!--[if IE 9]> <html class="no-js ie9 oldie" lang="en"> <![endif]-->
    <meta charset="utf-8">
    <!-- Set the viewport width to device width for mobile -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="Coming soon, Bootstrap, Bootstrap 3.0, Free Coming Soon, free coming soon, free template, coming soon template, Html template, html template, html5, Code lab, codelab, codelab coming soon template, bootstrap coming soon template">
    <link rel="shortcut icon" type="image/x-icon" href="../img/favicon.ico" />
    <title>Delfinch The Advance Home Care</title>
    <!-- ============ Google fonts ============ -->
    <link href='http://fonts.googleapis.com/css?family=EB+Garamond' rel='stylesheet'
        type='text/css' />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300,800'
        rel='stylesheet' type='text/css' />
    <!-- ============ Add custom CSS here ============ -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
      <link href="css/style.css" rel="stylesheet" type="text/css" />

    <link href="css/font-awesome.css" rel="stylesheet" type="text/css" />


</head>
<body>
    <div id="custom-bootstrap-menu" class="navbar navbar-default " role="navigation">
        <div class="navbar-header"><img src="../img/logos/logo.png" width="225px" height="100px" alt="logo" ></img>


            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-menubuilder"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
            </button>
        </div>
      <div class="collapse navbar-collapse navbar-menubuilder">
            <ul class="nav navbar-nav navbar-right">
            </li>
                <li><a href="../index.html">HOME</a>
                <li><a href="../index.html#how-we-work">HOW WE WORK</a>
                </li>
                <li><a href="../index.html#about">ABOUT US</a>
                </li>
                <li><a href="../index.html#team">TEAM</a>
                </li>
                <li><a href=../indedx.html#get-in-touch>GET IN TOUCH</a>
                </li>
                <li><a href="../index.html#contact">CONTACT US</a>
              <li class="nav-item">
                    <a class="nav-link" href="tel:+91-757-500-7779">CALL ON&nbsp;&nbsp;&nbsp;<img src="../img/phone.png" alt="Whats Up" height="17" width="17"> 7575007779</a>
                  </li>
                </li>
            </ul>
        </div>
    </div>
</div>

        <div class="container">
          <!-- <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center"> -->

            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="registrationform">
            <form class="form-horizontal" method="post" id="form1">
                <fieldset>
                    <legend>Registration Form <i class="fa fa-pencil pull-right"></i></legend>
                    <div class="form-group">
                        <label for="select" class="col-lg-2 control-label">
                            Services</label>
                        <div class="col-lg-10">
                            <select class="form-control" class="required" name="service" id="service" required style="color:gray">
                              <option disable hidden value="">--Select Service--</option>
                      				<option>Plumbing</option>
                      				<option>Electric</option>
                      				<option>A.C</option>
                      				<option>Refrigerator</option>
                      				<option>Washing Machine</option>
                      				<option>Tiling</option>
                      				<option>Painting</option>
                      				<option>Masonry Work</option>
                      				<option>Home Renovation</option>
                      				<option>Gym Tutor</option>
                      				<option>Yoga Tutor</option>
                      				<option>Computer and Laptop Repairing</option>
                      				<option>Legal Consultant</option>
                      				</select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="select" class="col-lg-2 control-label">
                            City</label>
                        <div class="col-lg-10">
                            <select class="form-control" class="required" name="city" id="select" required style="color:gray">
                              <option disable hidden value="">--Select City--</option>
                              <option>Ahmedabad</option>
                              <option>Baroda</option>
                              <option>Mumbai</option>
                              <option>Pune</option>
                              <option disabled style="color:red" value="null">Launching Soon</option>
                              <option disabled>Banglore</option>
                              <option disabled>Jaipur</option>
                              <option disabled>Delhi</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputText" class="col-lg-2 control-label">
                            Name</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="name" id="inputText" placeholder="Enter Name" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="inputPhone" class="col-lg-2 control-label">
                            Phone</label>
                        <div class="col-lg-10">
                            <input type="Mobile" class="form-control" name="phone" id="inputPhone" placeholder="Enter mobile number" required>
                        </div>
                    </div>

                            <div class="form-group">
                    <label for="inputEmail" class="col-lg-2 control-label">
                            Email</label>
                        <div class="col-lg-10">
                            <input type="text" class="form-control" name="email" id="inputEmail" placeholder="Email" required>
                        </div>
                      </div>

                    <div class="form-group">
                        <label for="textArea" class="col-lg-2 control-label">
                            Address</label>
                        <div class="col-lg-10">
                            <textarea class="form-control" rows="2" name="address" id="textArea" required></textarea>
                           <span class="help-block">Address should be in this format House NO.,Building.,Colony, Street, Locality/Area,PIN Code.</span>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" required>
                                        Checkbox
                                    </label>
                                </div>
                                <span class="help-block">I'm agree.</span>
                        </div>
                    </div>


                    <div class="form-group">
                        <div class="col-lg-10 col-lg-offset-2">
                            <button type="reset" class="btn btn-warning">
                                Cancel</button>
                            <button type="submit" name="submit" class="btn btn-primary">
                                Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>
         </div>




        </div>
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/jquery.backstretch.js" type="text/javascript"></script>
        <script type="text/javascript">
            'use strict';

            /* ========================== */
            /* ::::::: Backstrech ::::::: */
            /* ========================== */
            // You may also attach Backstretch to a block-level element
            $.backstretch(
        [
            "img/44.jpg",
            "img/colorful.jpg",
            "img/34.jpg",
            "img/images.jpg"
        ],

        {
            duration: 4500,
            fade: 1500
        }
    );
        </script>

</body>
</html>
